package emulator_utils;

public class test {
	public static void main(String[] args) {
		short s = (short) 0XF000; //1100
		System.out.println(s);
//		short a = (short) s >> 12;
//		System.out.println((short) s >>> 12);
		System.out.println((s>>>12)%16);
	}
}
