package emulator_utils;

public class Decoder {
	
	
	static public int decode(String instruction) {
		int out = 0;
		//here we put in switch statements
		switch(instruction) {
			case "HLT":
				out = 0;
				break;
			
			case "LDA":
				out = 1;
				break;
			
			case "STA":
				out = 2;
				break;
			
			case "AND":
				out = 3;
				break;
			
			case "ADD":
				out = 4;
				break;
				
			case "ISZ":
				out = 5;
				break;
				
			case "BUN":
				out = 6;
				break;
			
			case "BSA":
				out = 7;
				break;
				
			case "CLA":
				out = 8;
				break;
				
			case "CLE":
				out = 9;
				break;
				
			case "CMA":
				out = 10;
				break;
				
			case "CIL":
				out = 11;
				break;
				
			case "CIR":
				out = 12;
				break;
				
			case "SZA":
				out = 13;
				break;
		}
		return 0;
	}
	
}
