package emulator_utils;
//
public class Emulator {
//	// Loading the machine language program in memory and initializing other register and flags
//	// Emulating PBC program execution
//	// Printing results (printing a specified range of memory locations).
//	// Logging the status signals and corresponding control word during each clock cycle in a file called pbclog.txt
//	
//	Memory m;
//	DataUnit d;
//	ControlUnit c;
//	boolean clock;
//	
//	public Emulator(short[] instructions, int start) {
//		//we need to load the memory here so there must be an argument for it
//		
//		//start is the starting address of the instructions in the memory
//		
//		m = new Memory(2048);
//		m.fill(instructions, start);
//		d = new DataUnit();
//		c = new ControlUnit();
//		clock = false;
//	}
//	
//	public void emulate() {
//		//set the start register to high
//		Status s;
//		CW cw;
//		
//		d.AC.load((short) 10);
////		for(int i = 0; i < 4; i++) {
////			s = d.getStatus();
////			System.out.println(s.toString());
////			cw = c.getCW(s);
////			System.out.println(cw.toString());
////			System.out.println(c.sequenceCounter);
////		}
//		
//	
//		
//	}
//	
//	
//	
//	public static void main(String[] args)  {
//		//here we define emulator which calls start
//		//set the s to 1
//		//emulator needs to get the state 
//		//the control unit need D1
//		
//		Emulator e = new Emulator(new short[2048], 0);
//		e.emulate();
//	}
	
	
	private DataUnit mDataUnit;
	private ControlUnit mControlUnit;
	private CW mCw;
	private Status mStatus;
	//private 
	Memory memory;
	
	public Emulator(short[] instructions, int start) {
		memory = new Memory(2048);
		memory.fill(instructions, start);
		mDataUnit=new DataUnit(memory);
		mControlUnit=new ControlUnit();
		mDataUnit.SC.clear();
		start2();
	}
	public void start2() {
	//mDataUnit.S.up
		mDataUnit.S.load((short)0x1);
		mDataUnit.PC.load((short) 0x0000);

		emulate();
	}
	public void emulate() {
		while(mDataUnit.S.getValue() != 0) {
			mStatus=mDataUnit.getStatus();
			mCw=mControlUnit.getCW2(mStatus);
			mDataUnit.updateState(mCw);
			System.out.println("SC: "+ mDataUnit.SC.getValue() + "\n\tStatus: "+mStatus.toString()+"\n\tCW: "+mCw.toString()+"\n\n" + mDataUnit.IR.getValue());
		}
		System.out.println(mDataUnit.getStatus());
//		for(int i = 0; i < 10; i++) {
//			mStatus=mDataUnit.getStatus();
//			mCw=mControlUnit.getCW2(mStatus);
//			mDataUnit.updateState(mCw);
//			System.out.println("SC: "+ mDataUnit.SC.getValue() + "\n\tStatus: "+mStatus.toString()+"\n\tCW: "+mCw.toString()+"\n\n");
//
//		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		 //create emulator object.
		//call emulator.start()
		short[] i=new short[2048];
//		i[0]=(short) 0x5000;
		
		//AND
		/*
		i[0] = (short) 0x1032;
		i[1] = (short) 0x3033;
		i[2] = (short) 0x2037;
		i[3] = (short) 0x0000; //hlt
		i[50] = (short) 0x0007;
		i[51] = (short) 0x0003;
		i[55] = (short) 0x0000; //answer
		
		System.out.println(e.memory.read(50));
		System.out.println(e.memory.read(51));
		System.out.println(e.memory.read(55));
		*/
		//ADD
		/*
		i[0] = (short) 0x1032;
		i[1] = (short) 0x4033;
		i[2] = (short) 0x2038;
		i[3] = (short) 0x0000; //hlt
		i[50] = (short) 0x0007;
		i[51] = (short) 0x0003;
		i[56] = (short) 0x0000; //answer
		
		System.out.println(e.memory.read(50));
		System.out.println(e.memory.read(51));
		System.out.println(e.memory.read(56));
		*/
		
		i[0] = (short) 0x1032;
		i[1] = (short) 0xB000;
		i[2] = (short) 0x2038;
		i[3] = (short) 0x0000; //hlt
		i[50] = (short) 0x0007;
		i[51] = (short) 0x0003;
		i[56] = (short) 0x0000; //answer
		
		//01
		//10
		//100
		
		Emulator e = new Emulator(i, 0);
		//emulator.start();
		System.out.println(e.memory.read(50));
		System.out.println(e.memory.read(51));
		System.out.println(e.memory.read(56));
	}
	
}
//
////get the state from the data unit
////get the control word using the state
////update the state using cw


